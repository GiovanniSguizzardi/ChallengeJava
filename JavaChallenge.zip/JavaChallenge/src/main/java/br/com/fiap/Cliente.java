package br.com.fiap;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;

public class Cliente {
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("localhost", 1521);
            ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());

            // Seletor de opções
            System.out.println("1 - Médicos Disponiveis");
            System.out.println("2 - Remédios");
            Scanner scanner = new Scanner(System.in);
            System.out.print("Digite a opção que deseja: ");
            int opcao = scanner.nextInt();

            // Tratamento das opções e envio ao Servidor
            if (opcao == 1) {
                Scanner scannermedico = new Scanner(System.in);
                System.out.print("\nDigite o ID do médico requisitado: ");
                // Envia o ID ao servidor
                int opcao_medico = scannermedico.nextInt();
                outputStream.writeInt(opcao_medico);
                outputStream.flush();
                // Recebe e exibe informações do Medico do servidor
                Medico medico = (Medico) inputStream.readObject();
                System.out.println(medico);

            } else if (opcao == 2) {
                Scanner scannerremedio = new Scanner(System.in);
                System.out.print("\nDigite o ID do remedio requisitado: ");
                // Envia o ID ao servidor
                int opcao_remedio = scannerremedio.nextInt();
                outputStream.writeInt(opcao_remedio);
                outputStream.flush();
                // Recebe e exibe informações do Remedio do servidor
                Remedios remedios = (Remedios) inputStream.readObject();
                System.out.println(remedios);
            }
            socket.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}