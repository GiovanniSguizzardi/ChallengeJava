package br.com.fiap.classes;

import javax.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name="tb_transacoes_financeiras")
@SequenceGenerator(name="transacoes_financeiras_seq", sequenceName = "tb_transacoes_financeiras_pk", allocationSize = 1)
public class TransacoesFinanceiras implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id_transacao", nullable = false)
    private int id;

    @Column(name="dt_transacao", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date dataTransacao;

    @Column(name="vl_transacao", nullable = false)
    private float valorTransacao;

    @ManyToOne
    @JoinColumn(name = "tb_convenios_id_convenio", nullable = false)
    private Convenios convenio;

    public TransacoesFinanceiras() {}

    public TransacoesFinanceiras(int id, Date dataTransacao, float valorTransacao, Convenios convenio) {
        this.id = id;
        this.dataTransacao = dataTransacao;
        this.valorTransacao = valorTransacao;
        this.convenio = convenio;
    }

    @Override
    public String toString() {
        return "[ Informações: Transações Financeiras ]" +
                "ID: " + id +
                ", Data da Transação: " + dataTransacao +
                ", Valor da Transação: " + valorTransacao +
                ", Convênio: " + convenio.getNomeConvenio(); // Assumindo que Convenios tem um método getNomeConvenio()
    }
}