package br.com.fiap.classes;

import javax.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.io.Serializable;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name="tb_cidade")
@SequenceGenerator(name="cidade_seq", sequenceName = "tb_cidade_pk", allocationSize = 1)
public class Cidade implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id_cidade", nullable = false)
    private int id;

    @Column(name="nm_cidade", nullable = false, length = 100)
    private String nomeCidade;

    @OneToMany(mappedBy = "cidade")
    private List<Bairro> bairros;

    @ManyToOne
    @JoinColumn(name = "tb_estado_id_estado", nullable = false)
    private Estado estado;

    @PostPersist // Executa o método após o persist
    private void executar() {
        System.out.println("Executando o método..");
    }

    public Cidade() {}

    public Cidade(int id, String nomeCidade, Estado estado) {
        this.id = id;
        this.nomeCidade = nomeCidade;
        this.estado = estado;
    }

    @Override
    public String toString() {
        return "[ Informações: Cidade ]" +
                "ID: " + id +
                ", Nome da Cidade: " + nomeCidade +
                ", Estado: " + estado.getNomeEstado(); // Assumindo que Estado tem um método getNomeEstado()
    }
}
