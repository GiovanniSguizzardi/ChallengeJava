package br.com.fiap.classes;

import javax.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.io.Serializable;

@Getter
@Setter
@Entity
@Table(name="tb_convenios")
@SequenceGenerator(name="convenios_seq", sequenceName = "tb_convenios_pk", allocationSize = 1)
public class Convenios implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id_convenio", nullable = false)
    private int id;

    @Column(name="nm_convenio", nullable = false, length = 100)
    private String nomeConvenio;

    public Convenios() {}

    public Convenios(int id, String nomeConvenio) {
        this.id = id;
        this.nomeConvenio = nomeConvenio;
    }

    @Override
    public String toString() {
        return "[ Informações: Convênios ]" +
                "ID: " + id +
                ", Nome do Convênio: " + nomeConvenio;
    }
}
