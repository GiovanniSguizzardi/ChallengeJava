package br.com.fiap.classes;

import javax.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.io.Serializable;

@Getter
@Setter
@Entity
@Table(name="tb_exames")
@SequenceGenerator(name="exames_seq", sequenceName = "tb_exames_pk", allocationSize = 1)
public class Exames implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id_exame", nullable = false)
    private int id;

    @Column(name="desc_exame", nullable = false, length = 200)
    private String descricaoExame;

    @Column(name="resultado_exame", nullable = false, length = 500)
    private String resultadoExame;

    @OneToOne
    @JoinColumn(name = "tb_procedimentos_id_procedimento", nullable = false)
    private Procedimentos procedimento;

    public Exames() {}

    public Exames(int id, String descricaoExame, String resultadoExame, Procedimentos procedimento) {
        this.id = id;
        this.descricaoExame = descricaoExame;
        this.resultadoExame = resultadoExame;
        this.procedimento = procedimento;
    }

    @Override
    public String toString() {
        return "[ Informações: Exames ]" +
                "ID: " + id +
                ", Descrição do Exame: " + descricaoExame +
                ", Resultado do Exame: " + resultadoExame +
                ", Procedimento: " + procedimento.getId();
    }
}
