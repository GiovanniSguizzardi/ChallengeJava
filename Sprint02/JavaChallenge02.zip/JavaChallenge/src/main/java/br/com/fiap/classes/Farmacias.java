package br.com.fiap.classes;

import javax.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.io.Serializable;

@Getter
@Setter
@Entity
@Table(name="tb_farmacias")
@SequenceGenerator(name="farmacias_seq", sequenceName = "tb_farmacias_pk", allocationSize = 1)
public class Farmacias implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id_farmacia", nullable = false)
    private int id;

    @Column(name="nm_farmacia", nullable = false, length = 100)
    private String nomeFarmacia;

    @ManyToOne
    @JoinColumn(name = "tb_medicamentos_id_medicamento", nullable = false)
    private Medicamentos medicamento;

    @ManyToOne
    @JoinColumn(name = "tb_enderecos_id_endereco", nullable = false)
    private Enderecos endereco;

    public Farmacias() {}

    public Farmacias(int id, String nomeFarmacia, Medicamentos medicamento, Enderecos endereco) {
        this.id = id;
        this.nomeFarmacia = nomeFarmacia;
        this.medicamento = medicamento;
        this.endereco = endereco;
    }

    @Override
    public String toString() {
        return "[ Informações: Farmácias ]" +
                "ID: " + id +
                ", Nome da Farmácia: " + nomeFarmacia +
                ", Medicamento: " + medicamento.getId();
    }
}
