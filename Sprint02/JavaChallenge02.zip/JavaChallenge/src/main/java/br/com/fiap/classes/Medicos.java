package br.com.fiap.classes;

import javax.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.io.Serializable;

@Getter
@Setter
@Entity
@Table(name="tb_medicos")
@SequenceGenerator(name="medicos_seq", sequenceName = "tb_medicos_pk", allocationSize = 1)
public class Medicos implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id_medico", nullable = false)
    private int id;

    @Column(name="nm_medico", nullable = false, length = 100)
    private String nomeMedico;

    @Column(name="crm_medico", nullable = false)
    private long crmMedico;

    @Column(name="salario_medico", nullable = false)
    private float salarioMedico;

    @ManyToOne
    @JoinColumn(name = "tb_especialidades_id_especialidade", nullable = false)
    private Especialidades especialidade;

    @OneToOne
    @JoinColumn(name = "tb_contatos_id_contato", nullable = false)
    private Contatos contato;

    @OneToOne
    @JoinColumn(name = "tb_enderecos_id_endereco", nullable = false)
    private Enderecos endereco;

    public Medicos() {}

    public Medicos(int id, String nomeMedico, long crmMedico, float salarioMedico, Especialidades especialidade, Contatos contato, Enderecos endereco) {
        this.id = id;
        this.nomeMedico = nomeMedico;
        this.crmMedico = crmMedico;
        this.salarioMedico = salarioMedico;
        this.especialidade = especialidade;
        this.contato = contato;
        this.endereco = endereco;
    }

    @Override
    public String toString() {
        return "[ Informações: Médicos ]" +
                "ID: " + id +
                ", Nome do Médico: " + nomeMedico +
                ", CRM: " + crmMedico +
                ", Salário: " + salarioMedico +
                ", Especialidade: " + especialidade.getNomeEspecialidade() + // Assumindo que Especialidades tem um método getNomeEspecialidade()
                ", Contato: " + contato.getEmailContato() + // Assumindo que Contatos tem um método getEmailContato()
                ", Endereço: " + endereco.getLogradouro(); // Assumindo que Enderecos tem um método getLogradouro()
    }
}
