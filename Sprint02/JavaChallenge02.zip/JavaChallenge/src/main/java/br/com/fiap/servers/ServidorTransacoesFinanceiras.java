package br.com.fiap.servers;
import br.com.fiap.classes.TransacoesFinanceiras;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class ServidorTransacoesFinanceiras {
    private static EntityManagerFactory entityManagerFactory;
    private static EntityManager entityManager;

    //Método para inicializar o EntityManager
    private static void initEntityManager() {
        entityManagerFactory = Persistence.createEntityManagerFactory("CLIENTE_ORACLE");
        entityManager = entityManagerFactory.createEntityManager();
    }

    //Método para fechar o EntityManager
    private static void closeEntityManager() {
        entityManager.close();
        entityManagerFactory.close();
    }

    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(1539);
            while (true) {
                Socket socket = serverSocket.accept();
                ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
                ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
                int id = inputStream.readInt();
                TransacoesFinanceiras transacoesFinanceiras = buscarPorId(id);
                outputStream.writeObject(transacoesFinanceiras);
                outputStream.flush();
                socket.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Método para buscar informações do Remedio no banco de dados
    private static TransacoesFinanceiras buscarPorId(int id) {

        initEntityManager();
        TransacoesFinanceiras transacoesFinanceiras = null;

        try {
            // Inicia uma transação
            entityManager.getTransaction().begin();

            // Consulta JPQL para buscar o Remedio pelo ID
            Query query = entityManager.createQuery("SELECT p FROM TransacoesFinanceiras p WHERE p.id = :id");
            query.setParameter("id", id);
            transacoesFinanceiras = (TransacoesFinanceiras) query.getSingleResult();

            // Commita a transação
            entityManager.getTransaction().commit();
        } catch (Exception e) {
            // Se houver uma exceção, rollback na transação
            if (entityManager.getTransaction().isActive()) {
                entityManager.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {
            closeEntityManager();
        }
        return transacoesFinanceiras;
    }
}
