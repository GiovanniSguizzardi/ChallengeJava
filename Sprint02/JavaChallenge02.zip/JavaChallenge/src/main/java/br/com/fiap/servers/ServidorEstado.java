package br.com.fiap.servers;
import br.com.fiap.classes.Estado;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class ServidorEstado {
    private static EntityManagerFactory entityManagerFactory;
    private static EntityManager entityManager;

    //Método para inicializar o EntityManager
    private static void initEntityManager() {
        entityManagerFactory = Persistence.createEntityManagerFactory("CLIENTE_ORACLE");
        entityManager = entityManagerFactory.createEntityManager();
    }

    //Método para fechar o EntityManager
    private static void closeEntityManager() {
        entityManager.close();
        entityManagerFactory.close();
    }

    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(1527);
            while (true) {
                Socket socket = serverSocket.accept();
                ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
                ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
                int id = inputStream.readInt();
                Estado estado = buscarPorId(id);
                outputStream.writeObject(estado);
                outputStream.flush();
                socket.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Método para buscar informações no banco de dados
    private static Estado buscarPorId(int id) {

        initEntityManager();
        Estado estado = null;

        try {
            // Inicia uma transação
            entityManager.getTransaction().begin();

            // Consulta JPQL para buscar pelo ID
            Query query = entityManager.createQuery("SELECT p FROM Estado p WHERE p.id = :id");
            query.setParameter("id", id);
            estado = (Estado) query.getSingleResult();

            // Commita a transação
            entityManager.getTransaction().commit();
        } catch (Exception e) {
            // Se houver uma exceção, rollback na transação
            if (entityManager.getTransaction().isActive()) {
                entityManager.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {
            closeEntityManager();
        }
        return estado;
    }
}