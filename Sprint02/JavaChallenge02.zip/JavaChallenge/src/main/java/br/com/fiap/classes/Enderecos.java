package br.com.fiap.classes;

import javax.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.io.Serializable;

@Getter
@Setter
@Entity
@Table(name="tb_enderecos")
@SequenceGenerator(name="enderecos_seq", sequenceName = "tb_enderecos_pk", allocationSize = 1)
public class Enderecos implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id_endereco", nullable = false)
    private int id;

    @Column(name="logradouro_end", nullable = false, length = 100)
    private String logradouro;

    @Column(name="numero_end", nullable = false)
    private int numero;

    @Column(name="complemento_end")
    private String complemento;

    @Column(name="cep_end", nullable = false)
    private int cep;

    @ManyToOne
    @JoinColumn(name = "tb_bairro_id_bairro", nullable = false)
    private Bairro bairro;

    public Enderecos() {}

    public Enderecos(int id, String logradouro, int numero, String complemento, int cep, Bairro bairro) {
        this.id = id;
        this.logradouro = logradouro;
        this.numero = numero;
        this.complemento = complemento;
        this.cep = cep;
        this.bairro = bairro;
    }

    @Override
    public String toString() {
        return "[ Informações: Endereços ]" +
                "ID: " + id +
                ", Logradouro: " + logradouro +
                ", Número: " + numero +
                ", Complemento: " + complemento +
                ", CEP: " + cep +
                ", Bairro: " + bairro.getId();
    }
}
