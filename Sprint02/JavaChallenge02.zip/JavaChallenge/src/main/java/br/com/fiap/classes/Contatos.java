package br.com.fiap.classes;

import javax.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.io.Serializable;

@Getter
@Setter
@Entity
@Table(name="tb_contatos")
@SequenceGenerator(name="contatos_seq", sequenceName = "tb_contatos_pk", allocationSize = 1)
public class Contatos implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id_contato", nullable = false)
    private int id;

    @Column(name="telefone_contato", nullable = false)
    private long telefoneContato;

    @Column(name="e_mail_contato", nullable = false, length = 100)
    private String emailContato;

    @Column(name="info_contato", nullable = false, length = 200)
    private String infoContato;

    public Contatos() {}

    public Contatos(int id, long telefoneContato, String emailContato, String infoContato) {
        this.id = id;
        this.telefoneContato = telefoneContato;
        this.emailContato = emailContato;
        this.infoContato = infoContato;
    }

    @Override
    public String toString() {
        return "[ Informações: Contatos ]" +
                "ID: " + id +
                ", Telefone: " + telefoneContato +
                ", Email: " + emailContato +
                ", Info: " + infoContato;
    }
}
