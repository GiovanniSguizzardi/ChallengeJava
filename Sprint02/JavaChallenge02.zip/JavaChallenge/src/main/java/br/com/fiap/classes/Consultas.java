package br.com.fiap.classes;

import javax.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.io.Serializable;

@Getter
@Setter
@Entity
@Table(name="tb_consultas")
@SequenceGenerator(name="consultas_seq", sequenceName = "tb_consultas_pk", allocationSize = 1)
public class Consultas implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id_consulta", nullable = false)
    private int id;

    @Column(name="detalhes_consulta", nullable = false, length = 200)
    private String detalhesConsulta;

    @OneToOne
    @JoinColumn(name = "tb_procedimentos_id_procedimento", nullable = false)
    private Procedimentos procedimento;

    public Consultas() {}

    public Consultas(int id, String detalhesConsulta, Procedimentos procedimento) {
        this.id = id;
        this.detalhesConsulta = detalhesConsulta;
        this.procedimento = procedimento;
    }

    @Override
    public String toString() {
        return "[ Informações: Consultas ]" +
                "ID: " + id +
                ", Detalhes da Consulta: " + detalhesConsulta +
                ", Procedimento: " + procedimento.getId();
    }
}
