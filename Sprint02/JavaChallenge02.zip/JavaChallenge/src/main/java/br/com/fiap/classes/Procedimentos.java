package br.com.fiap.classes;

import javax.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name="tb_procedimentos")
@SequenceGenerator(name="procedimentos_seq", sequenceName = "tb_procedimentos_pk", allocationSize = 1)
public class Procedimentos implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id_procedimento", nullable = false)
    private int id;

    @Column(name="desc_procedimento", nullable = false, length = 200)
    private String descricaoProcedimento;

    @Column(name="dt_procedimento", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date dataProcedimento;

    @ManyToOne
    @JoinColumn(name = "tb_tp_procedimento_id_tp_procedimento", nullable = false)
    private TipoProcedimento tipoProcedimento;

    @ManyToOne
    @JoinColumn(name = "tb_transacoes_financeiras_id_transacao", nullable = false)
    private TransacoesFinanceiras transacaoFinanceira;

    @ManyToOne
    @JoinColumn(name = "tb_pacientes_id_paciente", nullable = false)
    private Pacientes paciente;

    @ManyToOne
    @JoinColumn(name = "tb_medicos_id_medico", nullable = false)
    private Medicos medico;

    @OneToOne
    @JoinColumn(name = "tb_prescricao_id_prescricao", nullable = false)
    private Prescricao prescricao;

    @ManyToOne
    @JoinColumn(name = "tb_enderecos_id_endereco", nullable = false)
    private Enderecos endereco;

    public Procedimentos() {}

    public Procedimentos(int id, String descricaoProcedimento, Date dataProcedimento, TipoProcedimento tipoProcedimento, TransacoesFinanceiras transacaoFinanceira, Pacientes paciente, Medicos medico, Prescricao prescricao, Enderecos endereco) {
        this.id = id;
        this.descricaoProcedimento = descricaoProcedimento;
        this.dataProcedimento = dataProcedimento;
        this.tipoProcedimento = tipoProcedimento;
        this.transacaoFinanceira = transacaoFinanceira;
        this.paciente = paciente;
        this.medico = medico;
        this.prescricao = prescricao;
        this.endereco = endereco;
    }

    @Override
    public String toString() {
        return "[ Informações: Procedimentos ]" +
                "ID: " + id +
                ", Descrição do Procedimento: " + descricaoProcedimento +
                ", Data do Procedimento: " + dataProcedimento +
                ", Tipo de Procedimento: " + tipoProcedimento.getId() +
                ", Transação Financeira: " + transacaoFinanceira.getId() +
                ", Paciente: " + paciente.getId() +
                ", Médico: " + medico.getId() +
                ", Prescrição: " + prescricao.getId() +
                ", Endereço: " + endereco.getLogradouro();
    }
}
