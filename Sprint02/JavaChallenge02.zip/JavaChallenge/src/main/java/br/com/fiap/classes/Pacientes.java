package br.com.fiap.classes;

import javax.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name="tb_pacientes")
@SequenceGenerator(name="pacientes_seq", sequenceName = "tb_pacientes_pk", allocationSize = 1)
public class Pacientes implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id_paciente", nullable = false)
    private int id;

    @Column(name="nm_paciente", nullable = false, length = 100)
    private String nomePaciente;

    @Column(name="dt_nasc_paciente", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date dataNascimento;

    @Column(name="sts_paciente", nullable = false, length = 1)
    private char statusPaciente;

    @ManyToOne
    @JoinColumn(name = "tb_tipopessoa_id_tipopessoa", nullable = false)
    private TipoPessoa tipoPessoa;

    @ManyToOne
    @JoinColumn(name = "tb_convenios_id_convenio")
    private Convenios convenio;

    @OneToOne
    @JoinColumn(name = "tb_contatos_id_contato", nullable = false)
    private Contatos contato;

    @OneToOne
    @JoinColumn(name = "tb_enderecos_id_endereco", nullable = false)
    private Enderecos endereco;

    public Pacientes() {}

    public Pacientes(int id, String nomePaciente, Date dataNascimento, char statusPaciente, TipoPessoa tipoPessoa, Convenios convenio, Contatos contato, Enderecos endereco) {
        this.id = id;
        this.nomePaciente = nomePaciente;
        this.dataNascimento = dataNascimento;
        this.statusPaciente = statusPaciente;
        this.tipoPessoa = tipoPessoa;
        this.convenio = convenio;
        this.contato = contato;
        this.endereco = endereco;
    }

    @Override
    public String toString() {
        return "[ Informações: Pacientes ]" +
                "ID: " + id +
                ", Nome do Paciente: " + nomePaciente +
                ", Data de Nascimento: " + dataNascimento +
                ", Status: " + statusPaciente +
                ", Tipo de Pessoa: " + tipoPessoa.getDescricao() + // Assumindo que TipoPessoa tem um método getDescricao()
                ", Convênio: " + (convenio != null ? convenio.getNomeConvenio() : "N/A") + // Assumindo que Convenios tem um método getNomeConvenio()
                ", Contato: " + contato.getEmailContato() + // Assumindo que Contatos tem um método getEmailContato()
                ", Endereço: " + endereco.getLogradouro(); // Assumindo que Enderecos tem um método getLogradouro()
    }
}
