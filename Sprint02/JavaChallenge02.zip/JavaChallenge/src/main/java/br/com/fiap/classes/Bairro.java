package br.com.fiap.classes;

import javax.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.io.Serializable;

@Getter
@Setter
@Entity
@Table(name="tb_bairro")
@SequenceGenerator(name="bairro_seq", sequenceName = "tb_bairro_pk", allocationSize = 1)
public class Bairro implements Serializable{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id_bairro", nullable = false)
    private int id;

    @Column(name="nm_bairro", nullable = false, length = 100)
    private String nm_bairro;

    @ManyToOne
    @JoinColumn(name = "id_cidade", nullable = false)
    private Cidade cidade;

    @PostPersist //Executa o metodo apos o persist
    private void executar() {
        System.out.println("Executando o método..");
    }

    public Bairro() {}

    public Bairro(int id, String nomeBairro, Cidade cidade) {
        this.id = id;
        this.nm_bairro = nomeBairro;
        this.cidade = cidade;
    }

    @Override
    public String toString() {
        return "[ Informações: Bairro ]" + '\'' +
                "ID: " + id + '\'' +
                "Nome do Bairro: " + nm_bairro + '\'' +
                "ID_Cidade: " + cidade;
    }
}
