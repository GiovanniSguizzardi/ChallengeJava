package br.com.fiap.classes;

import javax.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.io.Serializable;

@Getter
@Setter
@Entity
@Table(name="tb_tipopessoa")
@SequenceGenerator(name="tipopessoa_seq", sequenceName = "tb_tipopessoa_pk", allocationSize = 1)
public class TipoPessoa implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id_tipopessoa", nullable = false)
    private int id;

    @Column(name="desc_tipopessoa", nullable = false, length = 100)
    private String descricao;

    public TipoPessoa() {}

    public TipoPessoa(int id, String descricao) {
        this.id = id;
        this.descricao = descricao;
    }

    @Override
    public String toString() {
        return "[ Informações: Tipo de Pessoa ]" +
                "ID: " + id +
                ", Descrição: " + descricao;
    }
}
