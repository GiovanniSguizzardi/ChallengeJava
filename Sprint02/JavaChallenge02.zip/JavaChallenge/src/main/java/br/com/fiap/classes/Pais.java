package br.com.fiap.classes;

import javax.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.io.Serializable;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name="tb_pais")
@SequenceGenerator(name="pais_seq", sequenceName = "tb_pais_pk", allocationSize = 1)
public class Pais implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id_pais", nullable = false)
    private int id;

    @Column(name="nm_pais", nullable = false, length = 100)
    private String nomePais;

    @OneToMany(mappedBy = "pais")
    private List<Estado> estados;

    public Pais() {}

    public Pais(int id, String nomePais) {
        this.id = id;
        this.nomePais = nomePais;
    }

    @Override
    public String toString() {
        return "[ Informações: País ]" +
                "ID: " + id +
                ", Nome do País: " + nomePais;
    }
}