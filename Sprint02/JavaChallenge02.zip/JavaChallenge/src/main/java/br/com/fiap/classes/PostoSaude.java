package br.com.fiap.classes;

import javax.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.io.Serializable;

@Getter
@Setter
@Entity
@Table(name="tb_postossaude")
@SequenceGenerator(name="postossaude_seq", sequenceName = "tb_postossaude_pk", allocationSize = 1)
public class PostoSaude implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id_postosaude", nullable = false)
    private int id;

    @Column(name="nm_postosaude", nullable = false, length = 100)
    private String nomePostoSaude;

    @ManyToOne
    @JoinColumn(name = "tb_enderecos_id_endereco", nullable = false)
    private Enderecos endereco;

    public PostoSaude() {}

    public PostoSaude(int id, String nomePostoSaude, Enderecos endereco) {
        this.id = id;
        this.nomePostoSaude = nomePostoSaude;
        this.endereco = endereco;
    }

    @Override
    public String toString() {
        return "[ Informações: Postos de Saúde ]" +
                "ID: " + id +
                ", Nome do Posto de Saúde: " + nomePostoSaude +
                ", Endereço: " + endereco.getLogradouro(); // Assumindo que Enderecos tem um método getLogradouro()
    }
}
