package br.com.fiap.classes;

import javax.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name="tb_medicamentos")
@SequenceGenerator(name="medicamentos_seq", sequenceName = "tb_medicamentos_pk", allocationSize = 1)
public class Medicamentos implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id_medicamento", nullable = false)
    private int id;

    @Column(name="nm_medicamento", nullable = false, length = 100)
    private String nomeMedicamento;

    @Column(name="validade_medicamento", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date validadeMedicamento;

    @Column(name="tp_medicamento", nullable = false, length = 100)
    private String tipoMedicamento;

    @Column(name="dosagem_medicamento", nullable = false, length = 200)
    private String dosagemMedicamento;

    @Column(name="descricao_medicamento", nullable = false, length = 500)
    private String descricaoMedicamento;

    public Medicamentos() {}

    public Medicamentos(int id, String nomeMedicamento, Date validadeMedicamento, String tipoMedicamento, String dosagemMedicamento, String descricaoMedicamento) {
        this.id = id;
        this.nomeMedicamento = nomeMedicamento;
        this.validadeMedicamento = validadeMedicamento;
        this.tipoMedicamento = tipoMedicamento;
        this.dosagemMedicamento = dosagemMedicamento;
        this.descricaoMedicamento = descricaoMedicamento;
    }

    @Override
    public String toString() {
        return "[ Informações: Medicamentos ]" +
                "ID: " + id +
                ", Nome do Medicamento: " + nomeMedicamento +
                ", Validade: " + validadeMedicamento +
                ", Tipo: " + tipoMedicamento +
                ", Dosagem: " + dosagemMedicamento +
                ", Descrição: " + descricaoMedicamento;
    }
}
