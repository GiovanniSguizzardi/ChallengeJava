package br.com.fiap.classes;

import javax.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
@Entity
@Table(name="tb_prescricao")
@SequenceGenerator(name="prescricao_seq", sequenceName = "tb_prescricao_pk", allocationSize = 1)
public class Prescricao implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id_prescricao", nullable = false)
    private int id;

    @Column(name="data_prescricao", nullable = false)
    @Temporal(TemporalType.DATE)
    private Date dataPrescricao;

    @Column(name="desc_prescricao", nullable = false, length = 500)
    private String descricaoPrescricao;

    @ManyToOne
    @JoinColumn(name = "tb_medicamentos_id_medicamento", nullable = false)
    private Medicamentos medicamento;

    public Prescricao() {}

    public Prescricao(int id, Date dataPrescricao, String descricaoPrescricao, Medicamentos medicamento) {
        this.id = id;
        this.dataPrescricao = dataPrescricao;
        this.descricaoPrescricao = descricaoPrescricao;
        this.medicamento = medicamento;
    }

    @Override
    public String toString() {
        return "[ Informações: Prescrição ]" +
                "ID: " + id +
                ", Data da Prescrição: " + dataPrescricao +
                ", Descrição da Prescrição: " + descricaoPrescricao +
                ", Medicamento: " + medicamento.getId();
    }
}
