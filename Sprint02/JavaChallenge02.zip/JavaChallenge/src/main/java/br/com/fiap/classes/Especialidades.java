package br.com.fiap.classes;

import javax.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.io.Serializable;

@Getter
@Setter
@Entity
@Table(name="tb_especialidades")
@SequenceGenerator(name="especialidades_seq", sequenceName = "tb_especialidades_pk", allocationSize = 1)
public class Especialidades implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id_especialidade", nullable = false)
    private int id;

    @Column(name="nm_especialidade", nullable = false, length = 100)
    private String nomeEspecialidade;

    public Especialidades() {}

    public Especialidades(int id, String nomeEspecialidade) {
        this.id = id;
        this.nomeEspecialidade = nomeEspecialidade;
    }

    @Override
    public String toString() {
        return "[ Informações: Especialidades ]" +
                "ID: " + id +
                ", Nome da Especialidade: " + nomeEspecialidade;
    }
}
