package br.com.fiap.servers;
import br.com.fiap.classes.*;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        try {
            // Seletor de opções
            System.out.println("+----+-------------------------+");
            System.out.println("| N° | Classe a ser escolhida  |");
            System.out.println("+----+-------------------------+");
            System.out.println("| 01 | Bairro                  |");
            System.out.println("| 02 | Cidade                  |");
            System.out.println("| 03 | Consultas               |");
            System.out.println("| 04 | Contatos                |");
            System.out.println("| 05 | Convenios               |");
            System.out.println("| 06 | Endereços               |");
            System.out.println("| 07 | Especialidades          |");
            System.out.println("| 08 | Estado                  |");
            System.out.println("| 09 | Exames                  |");
            System.out.println("| 10 | Farmacias               |");
            System.out.println("| 11 | Medicamentos            |");
            System.out.println("| 12 | Medicos                 |");
            System.out.println("| 13 | Pacientes               |");
            System.out.println("| 14 | País                    |");
            System.out.println("| 15 | Postos de Saúde         |");
            System.out.println("| 16 | Prescrições             |");
            System.out.println("| 17 | Procedimentos           |");
            System.out.println("| 18 | Tipo de Pessoas         |");
            System.out.println("| 19 | Tipo de Procedimentos   |");
            System.out.println("| 20 | Transações Financeiras  |");
            System.out.println("+----+-------------------------+");
            Scanner scanner = new Scanner(System.in);
            System.out.print("--> Selecione a opção de (1-20): ");
            int opcao = scanner.nextInt();
            // Tratamento das opções e envio ao Servidor


            // CLASSE "Bairro" --> Porta:1520
            if (opcao == 1) {
                Scanner scannerbairro = new Scanner(System.in);
                System.out.print("\nDigite o ID do BAIRRO: ");

                // Envia o ID ao servidor
                int opcao_bairro = scannerbairro.nextInt();
                Socket socket = new Socket("localhost", 1520);
                ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
                outputStream.writeInt(opcao_bairro);
                outputStream.flush();

                // Recebe e exibe informações no servidor
                ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
                Bairro bairro = (Bairro) inputStream.readObject();
                System.out.println(bairro);
                socket.close();

            // CLASSE "Cidade" --> Porta:1521
            } else if (opcao == 2) {
                Scanner scannercidade = new Scanner(System.in);
                System.out.print("\nDigite o ID da CIDADE: ");

                // Envia o ID ao servidor
                int opcao_cidade = scannercidade.nextInt();
                Socket socket = new Socket("localhost", 1521);
                ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
                outputStream.writeInt(opcao_cidade);
                outputStream.flush();

                // Recebe e exibe informações no servidor
                ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
                Cidade cidade = (Cidade) inputStream.readObject();
                System.out.println(cidade);
                socket.close();

                // CLASSE "Consultas" --> Porta:1522
            } else if (opcao == 3) {
                Scanner scannerconsultas = new Scanner(System.in);
                System.out.print("\nDigite o ID da CONSULTA: ");

                // Envia o ID ao servidor
                int opcao_consulta = scannerconsultas.nextInt();
                Socket socket = new Socket("localhost", 1522);
                ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
                outputStream.writeInt(opcao_consulta);
                outputStream.flush();

                // Recebe e exibe informações no servidor
                ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
                Consultas consultas = (Consultas) inputStream.readObject();
                System.out.println(consultas);
                socket.close();

                // CLASSE "Contatos" --> Porta:1523
            } else if (opcao == 4) {
                Scanner scannercontatos = new Scanner(System.in);
                System.out.print("\nDigite o ID do CONTATO: ");

                // Envia o ID ao servidor
                int opcao_contatos = scannercontatos.nextInt();
                Socket socket = new Socket("localhost", 1523);
                ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
                outputStream.writeInt(opcao_contatos);
                outputStream.flush();

                // Recebe e exibe informações no servidor
                ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
                Contatos contatos = (Contatos) inputStream.readObject();
                System.out.println(contatos);
                socket.close();

                // CLASSE "Convenios" --> Porta:1524
            } else if (opcao == 5) {
                Scanner scannerconvenio = new Scanner(System.in);
                System.out.print("\nDigite o ID do CONVENIO: ");

                // Envia o ID ao servidor
                int opcao_convenio = scannerconvenio.nextInt();
                Socket socket = new Socket("localhost", 1524);
                ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
                outputStream.writeInt(opcao_convenio);
                outputStream.flush();

                // Recebe e exibe informações no servidor
                ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
                Convenios convenios = (Convenios) inputStream.readObject();
                System.out.println(convenios);
                socket.close();

                // CLASSE "Enderecos" --> Porta:1525
            } else if (opcao == 6) {
                Scanner scannerendereco = new Scanner(System.in);
                System.out.print("\nDigite o ID do ENDEREÇO: ");

                // Envia o ID ao servidor
                int opcao_endereco = scannerendereco.nextInt();
                Socket socket = new Socket("localhost", 1525);
                ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
                outputStream.writeInt(opcao_endereco);
                outputStream.flush();

                // Recebe e exibe informações no servidor
                ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
                Enderecos enderecos = (Enderecos) inputStream.readObject();
                System.out.println(enderecos);
                socket.close();

                // CLASSE "Especialidades" --> Porta:1526
            } else if (opcao == 7) {
                Scanner scannerespecialidades = new Scanner(System.in);
                System.out.print("\nDigite o ID da ESPECIALIDADE: ");

                // Envia o ID ao servidor
                int opcao_especialidade = scannerespecialidades.nextInt();
                Socket socket = new Socket("localhost", 1526);
                ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
                outputStream.writeInt(opcao_especialidade);
                outputStream.flush();

                // Recebe e exibe informações no servidor
                ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
                Especialidades especialidades = (Especialidades) inputStream.readObject();
                System.out.println(especialidades);
                socket.close();

                // CLASSE "Estado" --> Porta:1527
            } else if (opcao == 8) {
                Scanner scannerestado = new Scanner(System.in);
                System.out.print("\nDigite o ID do ESTADO: ");

                // Envia o ID ao servidor
                int opcao_estado = scannerestado.nextInt();
                Socket socket = new Socket("localhost", 1527);
                ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
                outputStream.writeInt(opcao_estado);
                outputStream.flush();

                // Recebe e exibe informações no servidor
                ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
                Estado estado = (Estado) inputStream.readObject();
                System.out.println(estado);
                socket.close();

                // CLASSE "Exames" --> Porta:1528
            } else if (opcao == 9) {
                Scanner scannerexames = new Scanner(System.in);
                System.out.print("\nDigite o ID do EXAME: ");

                // Envia o ID ao servidor
                int opcao_exame = scannerexames.nextInt();
                Socket socket = new Socket("localhost", 1528);
                ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
                outputStream.writeInt(opcao_exame);
                outputStream.flush();

                // Recebe e exibe informações no servidor
                ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
                Exames exames = (Exames) inputStream.readObject();
                System.out.println(exames);
                socket.close();

                // CLASSE "Farmacias" --> Porta:1529
            } else if (opcao == 10) {
                Scanner scannerfarmacias = new Scanner(System.in);
                System.out.print("\nDigite o ID da FARMACIA: ");

                // Envia o ID ao servidor
                int opcao_farmacias = scannerfarmacias.nextInt();
                Socket socket = new Socket("localhost", 1529);
                ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
                outputStream.writeInt(opcao_farmacias);
                outputStream.flush();

                // Recebe e exibe informações no servidor
                ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
                Farmacias farmacias = (Farmacias) inputStream.readObject();
                System.out.println(farmacias);
                socket.close();

                // CLASSE "Medicamentos" --> Porta:1530
            } else if (opcao == 11) {
                Scanner scannermedicamento = new Scanner(System.in);
                System.out.print("\nDigite o ID do MEDICAMENTO: ");

                // Envia o ID ao servidor
                int opcao_medicamento = scannermedicamento.nextInt();
                Socket socket = new Socket("localhost", 1530);
                ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
                outputStream.writeInt(opcao_medicamento);
                outputStream.flush();

                // Recebe e exibe informações no servidor
                ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
                Medicamentos medicamentos = (Medicamentos) inputStream.readObject();
                System.out.println(medicamentos);
                socket.close();

                // CLASSE "Medicos" --> Porta:1531
            } else if (opcao == 12) {
                Scanner scannermedicos = new Scanner(System.in);
                System.out.print("\nDigite o ID do MEDICO: ");

                // Envia o ID ao servidor
                int opcao_medicos = scannermedicos.nextInt();
                Socket socket = new Socket("localhost", 1531);
                ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
                outputStream.writeInt(opcao_medicos);
                outputStream.flush();

                // Recebe e exibe informações no servidor
                ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
                Medicos medicos = (Medicos) inputStream.readObject();
                System.out.println(medicos);
                socket.close();

                // CLASSE "Pacientes" --> Porta:1532
            } else if (opcao == 13) {
                Scanner scannerpacientes = new Scanner(System.in);
                System.out.print("\nDigite o ID do PACIENTE: ");

                // Envia o ID ao servidor
                int opcao_pacientes = scannerpacientes.nextInt();
                Socket socket = new Socket("localhost", 1532);
                ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
                outputStream.writeInt(opcao_pacientes);
                outputStream.flush();

                // Recebe e exibe informações no servidor
                ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
                Pacientes pacientes = (Pacientes) inputStream.readObject();
                System.out.println(pacientes);
                socket.close();

                // CLASSE "País" --> Porta:1533
            } else if (opcao == 14) {
                Scanner scannerpais = new Scanner(System.in);
                System.out.print("\nDigite o ID do PAÍS: ");

                // Envia o ID ao servidor
                int opcao_pais = scannerpais.nextInt();
                Socket socket = new Socket("localhost", 1533);
                ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
                outputStream.writeInt(opcao_pais);
                outputStream.flush();

                // Recebe e exibe informações no servidor
                ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
                Pais pais = (Pais) inputStream.readObject();
                System.out.println(pais);
                socket.close();

                // CLASSE "PostoSaúde" --> Porta:1534
            } else if (opcao == 15) {
                Scanner scannerpsaude = new Scanner(System.in);
                System.out.print("\nDigite o ID do POSTO DE SAÚDE: ");

                // Envia o ID ao servidor
                int opcao_psaude = scannerpsaude.nextInt();
                Socket socket = new Socket("localhost", 1534);
                ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
                outputStream.writeInt(opcao_psaude);
                outputStream.flush();

                // Recebe e exibe informações no servidor
                ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
                PostoSaude postoSaude = (PostoSaude) inputStream.readObject();
                System.out.println(postoSaude);
                socket.close();

                // CLASSE "Prescricao" --> Porta:1535
            } else if (opcao == 16) {
                Scanner scannerprescricao = new Scanner(System.in);
                System.out.print("\nDigite o ID da PRESCRIÇÃO: ");

                // Envia o ID ao servidor
                int opcao_prescricao = scannerprescricao.nextInt();
                Socket socket = new Socket("localhost", 1535);
                ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
                outputStream.writeInt(opcao_prescricao);
                outputStream.flush();

                // Recebe e exibe informações no servidor
                ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
                Prescricao prescricao = (Prescricao) inputStream.readObject();
                System.out.println(prescricao);
                socket.close();

                // CLASSE "Procedimentos" --> Porta:1536
            } else if (opcao == 17) {
                Scanner scannerprocedimento = new Scanner(System.in);
                System.out.print("\nDigite o ID do PROCEDIMENTO: ");

                // Envia o ID ao servidor
                int opcao_procedimento = scannerprocedimento.nextInt();
                Socket socket = new Socket("localhost", 1536);
                ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
                outputStream.writeInt(opcao_procedimento);
                outputStream.flush();

                // Recebe e exibe informações no servidor
                ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
                Procedimentos procedimentos = (Procedimentos) inputStream.readObject();
                System.out.println(procedimentos);
                socket.close();

                // CLASSE "TipoPessoa" --> Porta:1537
            } else if (opcao == 18) {
                Scanner scannertppessoa = new Scanner(System.in);
                System.out.print("\nDigite o ID do TIPO DA PESSOA: ");

                // Envia o ID ao servidor
                int opcao_tppessoa = scannertppessoa.nextInt();
                Socket socket = new Socket("localhost", 1537);
                ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
                outputStream.writeInt(opcao_tppessoa);
                outputStream.flush();

                // Recebe e exibe informações da Cidade no servidor
                ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
                TipoPessoa tipoPessoa = (TipoPessoa) inputStream.readObject();
                System.out.println(tipoPessoa);
                socket.close();

                // CLASSE "TipoProcedimento" --> Porta:1538
            } else if (opcao == 19) {
                Scanner scannertpprocedimento = new Scanner(System.in);
                System.out.print("\nDigite o ID do TIPO DE PROCEDIMENTO: ");

                // Envia o ID ao servidor
                int opcao_tpprocedimento = scannertpprocedimento.nextInt();
                Socket socket = new Socket("localhost", 1538);
                ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
                outputStream.writeInt(opcao_tpprocedimento);
                outputStream.flush();

                // Recebe e exibe informações no servidor
                ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
                TipoProcedimento tipoProcedimento = (TipoProcedimento) inputStream.readObject();
                System.out.println(tipoProcedimento);
                socket.close();

                // CLASSE "TransaçõesFinanceiras" --> Porta:1539
            } else if (opcao == 20) {
                Scanner scannertfinanceiras = new Scanner(System.in);
                System.out.print("\nDigite o ID da TRANSAÇÃO FINANCEIRA: ");

                // Envia o ID ao servidor
                int opcao_tfinanceiras = scannertfinanceiras.nextInt();
                Socket socket = new Socket("localhost", 1539);
                ObjectOutputStream outputStream = new ObjectOutputStream(socket.getOutputStream());
                outputStream.writeInt(opcao_tfinanceiras);
                outputStream.flush();

                // Recebe e exibe informações no servidor
                ObjectInputStream inputStream = new ObjectInputStream(socket.getInputStream());
                TransacoesFinanceiras transacoesFinanceiras = (TransacoesFinanceiras) inputStream.readObject();
                System.out.println(transacoesFinanceiras);
                socket.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}