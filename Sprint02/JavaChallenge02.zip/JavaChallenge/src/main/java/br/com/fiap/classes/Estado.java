package br.com.fiap.classes;

import javax.persistence.*;
import lombok.Getter;
import lombok.Setter;
import java.io.Serializable;
import java.util.List;

@Getter
@Setter
@Entity
@Table(name="tb_estado")
@SequenceGenerator(name="estado_seq", sequenceName = "tb_estado_pk", allocationSize = 1)
public class Estado implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="id_estado", nullable = false)
    private int id;

    @Column(name="nm_estado", nullable = false, length = 100)
    private String nomeEstado;

    @ManyToOne
    @JoinColumn(name = "tb_pais_id_pais", nullable = false)
    private Pais pais;

    @OneToMany(mappedBy = "estado")
    private List<Cidade> cidades;

    public Estado() {}

    public Estado(int id, String nomeEstado, Pais pais) {
        this.id = id;
        this.nomeEstado = nomeEstado;
        this.pais = pais;
    }

    @Override
    public String toString() {
        return "[ Informações: Estado ]" +
                "ID: " + id +
                ", Nome do Estado: " + nomeEstado +
                ", País: " + pais.getNomePais(); // Assumindo que Pais tem um método getNomePais()
    }
}
