package br.com.fiap;
import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name="TB_MEDICOS")
//name: nome igual ao generator, sequenceName: nome no Banco, allocationSize: incremento
@SequenceGenerator(name="medico", sequenceName = "", allocationSize = 1)
public class Medico implements Serializable{

    @Id
    @Column(name="ID_MEDICO")
    private int id;

    @Column(name="NM_MEDICO", nullable = false, length = 100)
    private String nome;

    @Temporal(TemporalType.DATE)
    @Column(name="DT_EXPERIENCIA")
    private Date experiencia;

    @Column(name="TP_ESPECIALIZACAO", nullable = false, length = 100)
    private String especializacao;

    public Medico() {}

    public Medico(int id, String nome, Date experiencia, String especializacao) {
        this.id = id;
        this.nome = nome;
        this.experiencia = experiencia;
        this.especializacao = especializacao;
    }

    @PostPersist //Executa o metodo apos o persist
    private void executar() {
        System.out.println("Executando o método..");
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Date getExperiencia() {
        return experiencia;
    }

    public void setExperiencia(Date experiencia) {
        this.experiencia = experiencia;
    }

    public String getEspecializacao() {
        return especializacao;
    }

    public void setEspecializacao(String especializacao) {
        this.especializacao = especializacao;
    }

    @Override
    public String toString() {
        return "\n[ Informações do Médico: ]" + "\n\r" +
                "ID: " + id + "\n\r" +
                "Nome: " + nome + "\n\r" +
                "Experiencia: " + experiencia + "\n\r" +
                "Especialização: " + especializacao
                ;
    }
}