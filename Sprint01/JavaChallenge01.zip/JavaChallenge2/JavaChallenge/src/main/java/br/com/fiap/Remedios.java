package br.com.fiap;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name="TB_REMEDIOS")
//name: nome igual ao generator, sequenceName: nome no Banco, allocationSize: incremento
@SequenceGenerator(name="remedios", sequenceName = "", allocationSize = 1)
public class Remedios implements Serializable {

    @Id
    @Column(name="ID_REMEDIO")
    private int id;

    @Column(name="NM_REMEDIO", nullable = false, length = 100)
    private String nome;

    @Temporal(TemporalType.DATE)
    @Column(name="DT_VALIDADE")
    private Date validade;

    @Column(name="TP_REMEDIO", nullable = false, length = 100)
    private String tipo;

    public Remedios() {}

    public Remedios(int id, String nome, Date validade, String tipo) {
        this.id = id;
        this.nome = nome;
        this.validade = validade;
        this.tipo = tipo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Date getValidade() {
        return validade;
    }

    public void setValidade(Date validade) {
        this.validade = validade;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "\n[ Informações do Remedio: ]" + "\n\r" +
                "ID: " + id + "\n\r" +
                "Nome: " + nome + "\n\r" +
                "Validade: " + validade + "\n\r" +
                "Tipo: " + tipo
                ;
    }
}
